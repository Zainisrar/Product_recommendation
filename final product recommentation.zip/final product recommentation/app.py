from flask import Flask, render_template, redirect, url_for, request
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph
from PyPDF2 import PdfReader
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.text_splitter import CharacterTextSplitter
from langchain.vectorstores import FAISS
from langchain.chains.question_answering import load_qa_chain
from langchain.llms import OpenAI
from langchain.chat_models import ChatOpenAI
from werkzeug.utils import secure_filename
import tempfile
import os

app = Flask(__name__)
# Set Environment Variables
os.environ["OPENAI_API_KEY"] = "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"
os.environ["SERPAPI_API_KEY"] = "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"
# Set up the upload folder
UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Paths for generated PDF and text file
pdf_path = os.path.join(app.config['UPLOAD_FOLDER'], 'generated.pdf')
text_file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'data.txt')

@app.route('/')
def home():
    return render_template('home.html')
@app.route('/data_entry')
def display_data_entry():
    return render_template('data_entry.html')

@app.route('/process_data_entry', methods=['POST'])
def process_data_entry():
    if request.method == 'POST':
        heading = request.form.get('heading', 'Default Heading')
        data = request.form['data']

        # Write markers and data to text file
        with open(text_file_path, "a") as text_file:
            text_file.write(f"HEADING_MARKER:{heading}\n")
            text_file.write(f"DATA_MARKER:{data}\n")
        
        # Read the text file content
        with open(text_file_path, 'r') as text_file:
            lines = text_file.readlines()

        # Define custom styles for heading and data
        heading_style = ParagraphStyle(
            'Heading1',
            fontName='Helvetica-Bold',
            fontSize=24,
            leading=30
        )
        
        data_style = ParagraphStyle(
            'DataStyle',
            fontName='Helvetica',
            fontSize=12,
            leading=14
        )

        # Generate flowables based on markers
        flowables = []
        for line in lines:
            line = line.strip()
            if "HEADING_MARKER:" in line:
                heading_text = line.replace("HEADING_MARKER:", "")
                flowables.append(Paragraph(heading_text, heading_style))
            elif "DATA_MARKER:" in line:
                data_text = line.replace("DATA_MARKER:", "")
                flowables.append(Paragraph(data_text, data_style))

        # Create the PDF
        pdf = SimpleDocTemplate(pdf_path, pagesize=letter)
        pdf.build(flowables)

        return render_template('data_entry.html', s="Successfully Form Filled")


@app.route('/text_about_data', methods=['GET', 'POST'])
def text_about_data():
    if request.method == 'POST':
        query = request.form['query']
        # provide the path of  pdf file/files.
        pdfreader = PdfReader("uploads/generated.pdf")
            # Read PDF file and extract text
        raw_text = ''
        for i, page in enumerate(pdfreader.pages):
            content = page.extract_text()
            if content:
                raw_text += content

            # Split text
        text_splitter = CharacterTextSplitter(separator="\n", chunk_size=800, chunk_overlap=200, length_function=len)
        texts = text_splitter.split_text(raw_text)

        # Download embeddings and search
        embeddings = OpenAIEmbeddings()
        document_search = FAISS.from_texts(texts, embeddings)

        # Query and run chain
        chain = load_qa_chain(OpenAI(), chain_type="stuff")
        docs = document_search.similarity_search(query)
        result = chain.run(input_documents=docs, question=query)

        return render_template('text_about_data.html', result=result)

    return render_template('text_about_data.html', result=None)

if __name__ == '__main__':
    app.run(debug=True)
