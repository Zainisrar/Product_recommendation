from flask import Flask, render_template, request
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph
import os

app = Flask(__name__)

# Set up the upload folder
UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Paths for generated PDF and text file
pdf_path = os.path.join(app.config['UPLOAD_FOLDER'], 'generated.pdf')
text_file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'data.txt')

@app.route('/')
def index():
    return render_template('data_entry.html')

@app.route('/generate-pdf', methods=['POST'])
def generate_pdf():
    if request.method == 'POST':
        heading = request.form.get('heading', 'Default Heading')
        data = request.form['data']
        
        # Write markers and data to text file
        with open(text_file_path, "a") as text_file:
            text_file.write(f"HEADING_MARKER:{heading}\n")
            text_file.write(f"DATA_MARKER:{data}\n")
        
        # Read the text file content
        with open(text_file_path, 'r') as text_file:
            lines = text_file.readlines()
        
        # Define custom styles for heading and data
        heading_style = ParagraphStyle(
            'Heading1',
            fontName='Helvetica-Bold',
            fontSize=24,
            leading=30
        )
        
        data_style = ParagraphStyle(
            'DataStyle',
            fontName='Helvetica',
            fontSize=12,
            leading=14
        )

        # Generate flowables based on markers
        flowables = []
        for line in lines:
            line = line.strip()
            if "HEADING_MARKER:" in line:
                heading_text = line.replace("HEADING_MARKER:", "")
                flowables.append(Paragraph(heading_text, heading_style))
            elif "DATA_MARKER:" in line:
                data_text = line.replace("DATA_MARKER:", "")
                flowables.append(Paragraph(data_text, data_style))
        
        # Create the PDF
        pdf = SimpleDocTemplate(pdf_path, pagesize=letter)
        pdf.build(flowables)
        s="Successfully Form Filled"

        return render_template('data_entry.html',s=s)

if __name__ == '__main__':
    app.run(debug=True)
