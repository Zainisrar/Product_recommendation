from flask import Flask, request, render_template
from PyPDF2 import PdfReader
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.text_splitter import CharacterTextSplitter
from langchain.vectorstores import FAISS
from langchain.chains.question_answering import load_qa_chain
from langchain.llms import OpenAI
from langchain.chat_models import ChatOpenAI
from werkzeug.utils import secure_filename
import tempfile
import os

app = Flask(__name__)

# Set Environment Variables
os.environ["OPENAI_API_KEY"] = "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"
os.environ["SERPAPI_API_KEY"] = "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"

@app.route('/query', methods=['GET', 'POST'])
def answer_query():
    if request.method == 'POST':
        query = request.form['query']
        # provide the path of  pdf file/files.
        pdfreader = PdfReader("python developer.pdf")
            # Read PDF file and extract text
        raw_text = ''
        for i, page in enumerate(pdfreader.pages):
            content = page.extract_text()
            if content:
                raw_text += content

            # Split text
        text_splitter = CharacterTextSplitter(separator="\n", chunk_size=800, chunk_overlap=200, length_function=len)
        texts = text_splitter.split_text(raw_text)

        # Download embeddings and search
        embeddings = OpenAIEmbeddings()
        document_search = FAISS.from_texts(texts, embeddings)

        # Query and run chain
        chain = load_qa_chain(OpenAI(), chain_type="stuff")
        docs = document_search.similarity_search(query)
        result = chain.run(input_documents=docs, question=query)

        return render_template('chat.html', result=result)

    return render_template('chat.html', result=None)

if __name__ == '__main__':
    app.run(debug=True)